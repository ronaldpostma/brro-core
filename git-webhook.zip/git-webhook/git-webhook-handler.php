<?php

function logToFile($message) {
    $logFile = __DIR__ . '/webhook.log';
    $currentTimestamp = date('Y-m-d H:i:s');
    $logMessage = "{$currentTimestamp}: {$message}\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

$secret = 'Bl9wqZI1QVuG7gkNLDMZEOxTaj2TB73d';
$headers = getallheaders();
$hubSignatureSHA256 = $headers['X-Hub-Signature-256'] ?? '';

// Expecting the signature to be in 'sha256=hash' format
list($algo256, $hash256) = explode('=', $hubSignatureSHA256, 2) + ['', ''];

$payload = file_get_contents('php://input');

// Calculate HMAC hash of the payload with your secret using SHA256
$payloadHashSHA256 = hash_hmac('sha256', $payload, $secret);

logToFile('Webhook triggered');

// Validate the payload against the SHA256 signature
if (!hash_equals($payloadHashSHA256, $hash256)) {
    logToFile('Invalid signature');
    http_response_code(403); // Forbidden
    echo 'Invalid signature';
    exit;
}

logToFile('Signature validated');

// Convert payload JSON into an array
$payloadData = json_decode($payload, true);
logToFile("Received payload: " . print_r($payloadData, true));
// Check if the event is a tag or release creation event
if ($payloadData['ref_type'] == 'tag') {
    $tagVersion = basename($payloadData['ref']);
    logToFile("New tag created: {$payloadData['ref']}");
    $pluginSlug = 'brro-core'; // Your plugin slug
    $userName = 'ronaldpostma'; // Your GitHub username

    $newVersion = $tagVersion;
    $packageUrl = "https://github.com/{$userName}/{$pluginSlug}/releases/download/{$tagVersion}/{$pluginSlug}-{$tagVersion}.zip";

    logToFile("Processing tag: {$tagVersion}");

    // Prepare the update information
    $pluginInfo = [
        'new_version' => $newVersion,
        'url' => "https://github.com/{$userName}/{$pluginSlug}/blob/main/README.md",
        'package' => $packageUrl,
        'tested' => '6.4', // Update this as necessary
    ];

    // Path to where your plugin-info.json is stored
    $pluginInfoPath = __DIR__ . '/brro-plugin-info.json';
    if (file_put_contents($pluginInfoPath, json_encode($pluginInfo, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
        logToFile('Successfully updated brro-plugin-info.json');
    } else {
        logToFile('Failed to update brro-plugin-info.json');
    }
} elseif (isset($payloadData['action']) && $payloadData['action'] == 'published' && isset($payloadData['release'])) {
    // This is a release event
    $tagName = $payloadData['release']['tag_name'];
    logToFile("New release published: {$tagName}");
    // Proceed with logic specific to handling a new release
} else {
    logToFile('Payload does not contain a tag push');
}

?>